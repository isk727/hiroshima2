<?php
if (is_file('./class/Slot.class.php')) { require_once('./class/Slot.class.php'); }
error_reporting(E_ALL);
 
$sb = new SlotBean();
$pdo = $sb->getPDO();
//$ret = $sb->modSlot("UPD", 1, "TEST", "192.168.1.1", 1);
$num = 1;
$name = 'test';
$ip = '192.168.0.1';
$id = 1;
$sql = "update slot set num=:num,name=:name,ip=:ip where id=:id";
$sth = $pdo->prepare($sql);
$sth->bindValue(':num', $num);
$sth->bindValue(':name', $name);
$sth->bindValue(':ip', $ip);
$sth->bindValue(':id', $id);
$ret = $sth->execute();

echo 'hello'.$ret;


//$ret = $sb->modSlot($req['com'], $req['id'], $req['name'], $req['ip'], $req['num']);
//$ret = $req['com'] . $req['id'] . $req['name'] . $req['ip'] .$req['num'];
//$result =[ "value" => $ret, ];
//$json = json_encode($result, JSON_UNESCAPED_UNICODE);
?>
