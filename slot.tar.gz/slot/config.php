<?php
define("DS", DIRECTORY_SEPARATOR);
define("_DEBUG", 1); // デバッグモード(0=無効, 1=有効)
define("_CHECKPING", 1); // 生存確認(0=しない, 1=する)
define("_NOACTIVE", "N/A"); // アクティブではない
define("_PORT", 50000); // ポート番号
define("_PORT_PREFIX", "6"); // ポート番号
define("_JSON_FILE", "http://_IP_/api/game.json");
define("_DBPATH", "/Library/WebServer/Documents/slot/db/slot.db");
?>
