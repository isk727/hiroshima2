<?php
if (is_file(dirname(__FILE__).DIRECTORY_SEPARATOR."DatasetBean.class.php")) { require_once(dirname(__FILE__).DIRECTORY_SEPARATOR."DatasetBean.class.php"); }

class SlotBean extends DatasetBean {
  public function makeQuery() {
        $query = "select ".
                    "id,".
                    "num,".
                    "name,".
                    "ip,".
                    "image,".
                    "gkey,".
                    "memo ".
                    "from slot ".
                    "where ".$this->where." ";
    if ($this->orderby == '') {
      $query .= "order by id";
    } else {
      $query .= "order by ".$this->orderby;
    }
    if ($this->limit > 0) {
      $query .= " limit ".$this->limit;
    }
    return $query;
  }

  public function getEntries() {
    $pdo = $this->getPDO();
    if ($pdo == null) {
      exit;
    }
    $stmt = $pdo->query($this->makeQuery());
//            $this->count = $stmt->rowCount();
    $rows = $stmt->fetchAll();
    $entries = array();
    foreach ($rows as $rs) {
      $slot = new Slot($rs);
      array_push($entries, $slot);
    }
    return $entries;
  }

  public function clearData($sid) {
    $pdo = $this->getPDO();
    if ($pdo == null) {
        exit;
    }
    $sql = "update game set disable=1 where slot_id=:id and stop_at<datetime('now','+09:00:00')";
    $sth = $pdo->prepare($sql);
    $sth->bindValue(':id', $sid);
    return $res = $sth->execute();
  }
    
  public function modSlot($com, $id, $name, $ip, $num) {
    $pdo = $this->getPDO();
    $ret = 0;
    if ($pdo == null) {
      exit;
    }
    if ($com == "ADD") {
      $sql = "insert into slot (num,name,ip,image,gkey) values (:num,:name,:ip,'','')";
      $sth = $pdo->prepare($sql);
      $sth->bindValue(':num', $num);
      $sth->bindValue(':name', $name);
      $sth->bindValue(':ip', $ip);
      $ret = $sth->execute();
    }
    if ($com == "UPD") {
      $sql = "update slot set num=:num,name=:name,ip=:ip where id=:id";
      $sth = $pdo->prepare($sql);
      $sth->bindValue(':num', $num);
      $sth->bindValue(':name', $name);
      $sth->bindValue(':ip', $ip);
      $sth->bindValue(':id', $id);
      $ret = $sth->execute();
    }
    if ($com == "DEL") {
      $sql = "delete from slot where id=:id";
      $sth = $pdo->prepare($sql);
      $sth->bindValue(':id', $id);
      $ret = $sth->execute();
    }
    return $ret;
  }

  public function modMemo($id, $memo) {
    $pdo = $this->getPDO();
    $ret = 0;
    if ($pdo == null) {
      exit;
    }
    $sql = "update slot set memo=:memo where id=:id";
    $sth = $pdo->prepare($sql);
    $sth->bindValue(':memo', $memo);
    $sth->bindValue(':id', $id);
    $ret = $sth->execute();
    return $ret;
  }

}

class Slot {
  public $id = '0';
  public $num = '';
  public $name = '';
  public $ip = '';
  public $image = '';
  public $gkey = "";
  public $memo = "";

  public function __construct() {
    $a = func_get_args();
    $i = func_num_args();
    if (method_exists($this, $f='__construct'.$i)) {
      call_user_func_array(array($this,$f), $a);
    }
  }
  function __construct0() {
  }
  function __construct1($row) {
    $this->id = $row['id'];
    $this->num = $row['num'];
    $this->name = $row['name'];
    $this->ip = $row['ip'];
    $this->gkey = $row['gkey'];
    $this->memo = $row['memo'];
  }
}
?>
