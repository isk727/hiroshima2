/*
 Navicat Premium Data Transfer

 Source Server         : slot
 Source Server Type    : SQLite
 Source Server Version : 3035005 (3.35.5)
 Source Schema         : main

 Target Server Type    : SQLite
 Target Server Version : 3035005 (3.35.5)
 File Encoding         : 65001

 Date: 01/03/2024 02:18:59
*/

PRAGMA foreign_keys = false;

-- ----------------------------
-- Table structure for game
-- ----------------------------
DROP TABLE IF EXISTS "game";
CREATE TABLE "game" (
  "id" INTEGER NOT NULL,
  "gkey" TEXT NOT NULL,
  "slot_id" INTEGER,
  "in_point" integer,
  "out_point" integer,
  "num_reg" integer,
  "num_big" integer,
  "start_date" DATE,
  "stop_date" DATE,
  PRIMARY KEY ("id", "gkey")
);

PRAGMA foreign_keys = true;
