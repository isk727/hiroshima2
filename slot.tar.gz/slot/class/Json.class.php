<?php
class Json {
    public function getJson($url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $res =  curl_exec($ch);
        $json = json_decode($res, true);
        curl_close($ch);
        return $json;
    }
    public function getX() {
        return "xxxxxx";
    }
}
?>
