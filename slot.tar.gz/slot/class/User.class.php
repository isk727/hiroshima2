<?php
if (is_file(dirname(__FILE__).DIRECTORY_SEPARATOR."DatasetBean.class.php")) { require_once(dirname(__FILE__).DIRECTORY_SEPARATOR."DatasetBean.class.php"); }

class UserBean extends DatasetBean {
    public function makeQuery() {
        $query = "select id, userid, password, name, admin from users where ".$this->where;
        if ($this->orderby == '') {
            $query .= " order by id";
        } else {
            $query .= " order by ".$this->orderby;
        }
        if ($this->limit > 0) {
            $query .= " limit ".$this->limit;
        }
        return $query;
    }

    public function getLoginUser($uid, $pwd) {
        $this->where = "userid='" . $uid . "'";
        $user = $this->getEntries();
        if (sizeof($user) != 1) {
            return -1;
        } else {
            $usr = $user[0];
            if ($this->vfyHashPwd($pwd, $usr->password)) {
                return $usr->userid.",".$usr->admin;
            } else {
                return -1;
            }
        }
    }

    private function vfyHashPwd($pwd, $hash) {
        return password_verify($pwd, $hash);
    }
    private function getHashPwd($pwd) {
        return password_hash($pwd, PASSWORD_DEFAULT);
    }

    public function addUser($uid, $pwd, $name, $admin) {
        $pdo = $this->getPDO();
        if ($pdo == null) {
            exit;
        }
        $sql = "insert into users (userid,password,`name`,admin) values (:uid,:pwd,:name,:admin)";
        $sth = $pdo->prepare($sql);
        $sth->bindValue(':uid', $uid);
        $sth->bindValue(':pwd', getHashPwd($pwd));
        $sth->bindValue(':name', $name);
        $sth->bindValue(':admin', $admin);
        return ($sth->execute());
    }

    public function getEntries() {
        $pdo = $this->getPDO();
        if ($pdo == null) {
            exit;
        }
        $stmt = $pdo->query($this->makeQuery());
        $ret = $this->makeQuery();
        $rows = $stmt->fetchAll();
        $entries = array();
        foreach ($rows as $rs) {
            $user = new User($rs);
            array_push($entries, $user);
        }
        return $entries;
    }

   public function modUser($com, $id, $userid, $name, $password, $admin) {
        $pdo = $this->getPDO();
        $ret = 0;
        if ($pdo == null) {
            exit;
        }
        if ($com == "ADD") {
            $sql = "insert into users (userid,`name`,password,admin) values (:userid,:name,:password,:admin)";
            $sth = $pdo->prepare($sql);
            $sth->bindValue(':userid', $userid);
            $sth->bindValue(':name', $name);
            $sth->bindValue(':password', $this->getHashPwd($password));
            $sth->bindValue(':admin', $admin);
            $ret = $sth->execute();
        }
        if ($com == "UPD") {
            $sql = "update users set userid=:userid,`name`=:name,password=:password,admin=:admin where id=:id";
            $sth = $pdo->prepare($sql);
            $sth->bindValue(':userid', $userid);
            $sth->bindValue(':name', $name);
            $sth->bindValue(':password',  $this->getHashPwd($password));
            $sth->bindValue(':admin', $admin);
            $sth->bindValue(':id', $id);
            $ret = $sth->execute();
        }
        if ($com == "DEL") {
            $sql = "delete from users where id=:id";
            $sth = $pdo->prepare($sql);
            $sth->bindValue(':id', $id);
            $ret = $sth->execute();
        }
        return $ret;
    }
}

class User
{
    public $id = '0';
    public $userid = '';
    public $password = '';
    public $name = '';
    public $admin = '0';

    public function __construct() {
        $a = func_get_args();
        $i = func_num_args();
        if (method_exists($this, $f='__construct'.$i)) {
            call_user_func_array(array($this,$f), $a);
        }
    }
    function __construct0() {
    }
    function __construct1($row) {
        $this->id = $row['id'];
        $this->userid = $row['userid'];
        $this->password = $row['password'];
        $this->name = $row['name'];
        $this->admin = $row['admin'];
    }
}
?>
