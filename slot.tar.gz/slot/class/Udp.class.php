<?php
if (is_file(dirname(__FILE__).DIRECTORY_SEPARATOR."DatasetBean.class.php")) { require_once(dirname(__FILE__).DIRECTORY_SEPARATOR."DatasetBean.class.php"); }
class UdpBean extends DatasetBean {
	public function makeQuery() {
        $query = "select id, ud, fm, pt, dt, fg, df from udp where ".$this->where." order by id";
		return $query;
	}

	public function getEntries() {
		$pdo = $this->getPDO();
		if ($pdo == null) {
    		exit;
		}
		$stmt = $pdo->query($this->makeQuery());
//			$this->count = $stmt->rowCount();
		$rows = $stmt->fetchAll();
		$entries = array();
		foreach ($rows as $rs) {
			$udp = new Udp($rs);
            array_push($entries, $udp);
		}
		return $entries;
	}

	public function setFlag($id, $fld) {
		$pdo = $this->getPDO();
		if ($pdo == null) {
			exit;
		}
		$sql = "update udp set ".$fld."=1 where id=:id";
		$sth = $pdo->prepare($sql);
		$sth->bindValue(':id', $id);
		$sth->execute();
	}

	public function getReturnVal($ip, $cmd) {
		$pdo = $this->getPDO();
		if ($pdo == null) {
    		exit;
		}
		$this->where = "fm='".$ip."' and ud like '".$cmd."%'";//" and fg=0"; // fg=0
		$stmt = $pdo->query($this->makeQuery());
		$this->count = $stmt->rowCount();
		$rows = $stmt->fetchAll();
		$entries = array();
		foreach ($rows as $rs) {
			$udp = new Udp($rs);
  			$ret = $udp->ud;
  			$bodytag = str_replace($cmd, "", $udp->ud);
		}
		return $bodytag;
	}

}

class Udp {
    public $id = '0';
    public $ud = '';
    public $fm = '';
    public $pt = '';
    public $dt = '';
    public $fg = ''; // 処理フラグ
    public $df = ''; // デバッグフラグ
    public function __construct() {
        $a = func_get_args();
        $i = func_num_args();
        if (method_exists($this, $f='__construct'.$i)) {
            call_user_func_array(array($this,$f), $a);
        }
    }
    function __construct0() {
    }
    function __construct1($row) {
		$this->id = $row['id'];
		$this->ud = $row['ud'];
		$this->fm = $row['fm'];
		$this->pt = $row['pt'];
		$this->dt = $row['dt'];
		$this->fg = $row['fg'];
		$this->fg = $row['df'];
	}
}
?>
