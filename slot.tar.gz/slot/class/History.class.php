<?php
if (is_file(dirname(__FILE__).DIRECTORY_SEPARATOR."DatasetBean.class.php")) { require_once(dirname(__FILE__).DIRECTORY_SEPARATOR."DatasetBean.class.php"); }

class HistoryBean extends DatasetBean {
	public function makeQuery() {
		$fmt = '%Y/%m/%d %H:%M';
        $query = "select ".
					"id,".
					"ip,".
					"op,".
					"dir,".
					"dt,".
					"strftime('".$fmt."', dt) as fdt ".
					"from history ".
					"where ".$this->where." ".
					"order by dt desc";
		return $query;
	}

	public function getEntries() {
		$pdo = $this->getPDO();
		if ($pdo == null) {
    		exit;
		}
		$stmt = $pdo->query($this->makeQuery());
//			$this->count = $stmt->rowCount();
		$rows = $stmt->fetchAll();
		$entries = array();
		foreach ($rows as $rs) {
			$history = new History($rs);
			array_push($entries, $history);
		}
		return $entries;
	}

	public function addHistory($ip, $op, $dir) {
		$pdo = $this->getPDO();
		if ($pdo == null) {
			exit;
		}
		$sql = "insert into history (ip, op, dir, dt) values (:ip,:op,:dir,datetime('now','localtime'))";
		$sth = $pdo->prepare($sql);
		$sth->bindValue(':ip', $ip);
		$sth->bindValue(':op', $op);
		$sth->bindValue(':dir', $dir);
		$sth->execute();
	}

	public function getLastUpdate($ip, $op, $dir) {
		$this->where = "ip='".$ip."' and op='".$op."' and dir=".$dir;
		$pdo = $this->getPDO();
		if ($pdo == null) {
    		exit;
		}
		$stmt = $pdo->query($this->makeQuery());
		$this->count = $stmt->rowCount();
		$rows = $stmt->fetchAll();
		$entries = array();
		foreach ($rows as $rs) {
			$history = new History($rs);
			$entries[] = $history;
		}
		return $entries;
	}
}

class History {
    public $id = '0';
    public $ip = '';
    public $op = '';
    public $dir = '';
    public $dt = '';
    public $fdt = '';
    public function __construct() {
        $a = func_get_args();
        $i = func_num_args();
        if (method_exists($this, $f='__construct'.$i)) {
            call_user_func_array(array($this,$f), $a);
        }
    }
    function __construct0() {
    }
    function __construct1($row) {
			$this->id = $row['id'];
			$this->ip = $row['ip'];
			$this->op = $row['op'];
			$this->dir = $row['dir'];
			$this->dt = $row['dt'];
			$this->fdt = $row['fdt'];
    }
}
?>
