<?php
if (is_file('./class/Slot.class.php')) { require_once('./class/Slot.class.php'); }
if (is_file('./class/Game.class.php')) { require_once('./class/Game.class.php'); }
$slb = new SlotBean();
$slb->where = "id=".$_GET['id'];
$slots = $slb->getEntries();
$slot = "";
if (count($slots) == 1) {
  $slot = $slots[0];
} else {
  header("Location: errorpage.php");
  exit();
}
$gb = new GameBean();
$gb->where = "slot_id=".$_GET['id']." and stop_at is not null";
$gb->orderby = "id desc";
$games = $gb->getEntries();
if (count($games) == 0) {
  header("Location: errorpage.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="HandheldFriendly" content="True" />
  <title>GAME</title>
  <link rel="icon" href="img/favicon.png" type="image/png">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://code.jquery.com/jquery-migrate-3.4.0.min.js" integrity="sha256-mBCu5+bVfYzOqpYyK4jm30ZxAZRomuErKEFJFIyrwvM=" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.6.1/js/iziModal.min.js"></script>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.6.1/css/iziModal.css">
  <link href="https://use.fontawesome.com/releases/v6.2.0/css/all.css" rel="stylesheet">
  <link rel="stylesheet" href="./css/style.css" media="screen">
  <style>
    .minus { color : red; }
    .plus { color: black; }
  </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light" style="background-color:#e3f2fd;">
  <div class="container-fluid text-center">
    <a class="navbar-brand" href="#"><span style="font-weight:bold;">履歴一覧</span>：<?= $slot->name ?></a>
  </div>
</nav>
<!-- ========================================================================= -->
<div class="table_frame" style="width:90%;">
<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">開始日時</th>
      <th scope="col"><div class="text-end">開始PT</div></th>
      <th scope="col"><div class="text-end">終了PT</div></th>
      <th scope="col"><div class="text-end">差PT</div></th>
      <th scope="col"><div class="text-end">回転数</div></th>
      <th scope="col"><div class="text-end">RB回数(回転数)</div></th>
      <th scope="col"><div class="text-end">BB回数(回転数)</div></th>
      <th scope="col">終了日時</th>
    </tr>
  </thead>
  <tbody>
<?php
$nn = 0;
foreach ($games as $game) { $nn += 1; 
  $cls = "plus";
  if ($game->diff_point < 0) { $cls = "minus";} 
  $tr = "table-light";
  if ($game->disable == 1) { $tr = "table-secondary"; }
?>
    <tr class="<?= $tr ?>">
      <th scope="row"><?= $nn ?></th>
      <td><?= $gb->formatDate($game->start_at) ?></td>
      <td><div class="text-end"><?= $game->in_point ?></div></td>
      <td><div class="text-end"><?= $game->out_point ?></div></td>
      <td><div class="text-end <?= $cls ?>"><?= $game->diff_point ?></div></td>
      <td><div class="text-end"><span style="font-weight:bold"><?= $game->bw_total ?></span></div></td>
      <td><div class="text-end"><span style="font-weight:bold"><?= $game->num_rb ?></span> (<?= $game->bw_rb ?>)</div></td>
      <td><div class="text-end"><span style="font-weight:bold"><?= $game->num_bb ?></span> (<?= $game->bw_bb ?>)</div></td>
      <td><?= $gb->formatDate($game->stop_at) ?></td>
    </tr>
  </tr>
<?php } ?>
  </tbody>
</table>
<div class="text-center">
<button id="btn-close" class="btn btn-secondary btn-sm btn-top-navi"><i class="fa-regular fa-circle-xmark"> 閉じる</i></button>
</div>
</div>
<!-- ========================================================================= -->
<script>
const winClose = () => {
  parent.location.reload();
  parent.$.fn.colorbox.close();
};

$(function() {
  $("#btn-close").on('click', function () { // 閉じる
    winClose();
  });
});
</script>
</body>
</html>