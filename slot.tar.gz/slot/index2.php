<?php
if (is_file(dirname(__FILE__)."/common.php")) { require_once(dirname(__FILE__)."/common.php"); }
if (is_file(dirname(__FILE__)."/config.php")) { require_once(dirname(__FILE__)."/config.php"); }
if (is_file('./class/Slot.class.php')) { require_once('./class/Slot.class.php'); }
if (is_file('./class/Setting.class.php')) { require_once('./class/Setting.class.php'); }
$sb = new SettingBean();
$values = $sb->getValues();
$buttons = $sb->getButtons();

if (isset($_POST["slotid"])) {
  $slb = new SlotBean();
  $slb->where = "id=".$_POST["slotid"];
  $slots = $slb->getEntries();
  $slot = $slots[0];
}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="HandheldFriendly" content="True" />
  <title>UDP2</title>
  <link rel="icon" href="img/favicon.png" type="image/png">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://code.jquery.com/jquery-migrate-3.4.0.min.js" integrity="sha256-mBCu5+bVfYzOqpYyK4jm30ZxAZRomuErKEFJFIyrwvM=" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.6.1/js/iziModal.min.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.6.1/css/iziModal.css">
<style>
.table-css { border-collapse: collapse;  }
.table2 { background-color:#fefefe; padding:8px 4px 6px 8px; margin-top: 0;} /*… ［上］ と ［右］ と ［下］ と ［左］ を指定*/
.td-css11 { border: 1px solid black; border-top-style:none; border-left-style:none; }
.td-css13 { border-style:none; }
.td-css0 { border: 0px;}
.td-css1 { border: 1px solid black; white-space: nowrap; }
.td-css2 { border: 1px solid black; font-size: 1.2em;text-align: right; font-weight: bold; white-space: nowrap;padding:2px 4px 8px 8px; }

.tmp-btn { width:10em; }
.tmp-btn2 { width:5em; }

.inptext { width:6em; height:2em; font-size: 1em;text-align: center; font-weight: bold;}
.tabletop0 { margin-top:0; }

.debugarea {
    width: 100%;
    height: 150px;
    padding: 5px;
    ;
    border-radius: 5px;
    border: 1px solid #a8aabc;
}
</style>
  <link rel="stylesheet" href="./css/style.css" media="screen">
</head>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">【<?= $slot->num ?>】<?= $slot->name ?>（<?= $slot->ip ?>）</a>
    <button id="btn-back" class="btn btn-primary btn-sm buttonlg">戻る  </button>
  </div>
</nav>

<table class="tabletop0">
  <tr>
    <td class="align-top"><!-- ------------ TABLE-LEFT ---------------- -->
<table class="table2">
  <tr><td colspan="4"> </td></tr>
  <tr class="align-top">
    <td><button id="cbtn-seisan" class="btn btn-primary btn-sm tmp-btn" >精算</button></td>
    <td></td>
    <td>
<?php if ($values['disp_set'] == 1) { ?>
      <button id="cbtn-set" class="btn btn-primary btn-sm tmp-btn" >設定変更</button>
<?php }  ?>
    </td>
    <td>
<?php if ($values['disp_set'] == 1) { ?>
      <select id="sel-set" class="form-select form-select-sm mb-3" aria-label=".form-select-lg example">
  <option value="0" selected>- 設定 -</option>
  <option value="1">1</option>
  <option value="2">2</option>
  <option value="3">3</option>
  <option value="4">4</option>
  <option value="5">5</option>
  <option value="6">6</option>
</select>
<?php }  ?>
</td>
  </tr>
  <tr class="align-top">
    <td><input id="txt-seisan" class="form-control" type="text" disabled></td>
    <td></td>
    <td>
<?php if ($values['disp_set_conf'] == 1) { ?>
      <button id="cbtn-set-conf" class="btn btn-primary btn-sm tmp-btn" >設定確認</button>
<?php } ?>
    </td>
    <td><input id="txt-set" class="form-control inptext" type="text" aria-label="Disabled input example" disabled></td>
  </tr>
  <tr class="align-top">
    <td><button id="cbtn-coin53" class="btn btn-primary btn-sm tmp-btn" >コイン53枚投入</button></td>
    <td>　　　　　</td>
    <td>　　　　　</td>
    <td>　　　　　</td>
  </tr>
  <tr class="align-top">
    <td class="text-nowrap"><button id="cbtn-auto-start" class="btn btn-primary btn-sm tmp-btn2" >オート</button><span> </span><button id="cbtn-auto-stop" class="btn btn-primary btn-sm tmp-btn2" >停止</button></td>
    <td>　　　　　</td>
    <td><button id="cbtn-reset" class="btn btn-primary btn-sm tmp-btn" >リセット</button></td>
    <td><input id="txt-reset" class="form-control inptext" type="text" aria-label="Disabled input example" disabled></td>
  </tr>
  <tr class="align-top">
    <td colspan="4">
<table class="tabletop0"><!-- ----------------------------- -->
  <tr>
    <td class="td-css1">現在PT</td>
    <td class="td-css1">購入PT累計</td>
    <td class="td-css1">清算PT累計</td>
    <td class="td-css0" colspan="3" rowspan="2"><div class="text-center"><button id="cbtn-read-data" class="btn btn-info btn-sm tmp-btn" >データ読み出し</button></span></td>
  </tr>
  <tr>
    <td class="td-css2"><div id="cur_point"></div></td>
    <td class="td-css2"><div id="buy_point"></div></td>
    <td class="td-css2"><div id="cls_poinst"></div></td>
    <!-- td class="td-css0" colspan="3"></td -->
  </tr>
 <!-- tr>
    <td class="td-css0" colspan="6" style="font-size:0.01"></td>
  </tr -->
  <tr>
    <td class="td-css1">IN枚数</td>
    <td class="td-css1">OUT枚数</td>
    <td class="td-css1">差枚数</td>
    <td class="td-css1">BIG回数</td>
    <td class="td-css1">REG回数</td>
    <td class="td-css1">特約回数</td>
  </tr>
  <tr>
    <td class="td-css2"><div id="inf_in"></div></td>
    <td class="td-css2"><div id="inf_out"></div></td>
    <td class="td-css2"><div id="inf_dif"></div></td>
    <td class="td-css2"><div id="inf_big"></div></td>
    <td class="td-css2"><div id="inf_reg"></div></td>
    <td class="td-css2"><div id="inf_sp"></div></td>
  </tr>
 <!-- tr>
    <td class="td-css0" colspan="6" style="font-size:0.01"></td>
  </tr -->
  <tr>
    <td class="td-css1">機械割</td>
    <td class="td-css0" colspan="5" ></td>
  </tr>
  <tr>
    <td class="td-css2"><div id="inf_pc"></div></td>
    <td class="td-css0" colspan="5" ></td>
  </tr>
</table>








    </td>
  </tr>
  <tr class="align-top">
    <td colspan="4"><textarea id="debug" class="debugarea"></textarea></td>
  </tr>
</table>

    </td>
    <td></td>
    <td class="align-top"><!-- ------------ TABLE-RIGTH ---------------- -->
<table class="table2">
    <tr><td colspan="2"> </td></tr>

  <tr>
    <td><button id="cbtn-buy-point" class="btn btn-primary btn-sm tmp-btn" >PT購入</button></td>
    <td><select id="sel-buy-point" class="form-select form-select-sm" aria-label=".form-select-lg example">
  <option value="0" selected>- 購入PT -</option>
  <option value="1000">1,000円</option>
  <option value="2000">2,000円</option>
  <option value="3000">3,000円</option>
  <option value="5000">5,000円</option>
  <option value="10000">10,000円</option>
</select>
</td>
  </tr>
  <tr>
    <td><button id="cbtn-point-setting" class="btn btn-primary btn-sm tmp-btn" >単価設定</button></td>
    <td><input type="number" id="txt-point-setting"></td>
  </tr>
  <tr><td colspan="2">　</td></tr>
  <tr>
    <td class="text-nowrap"><button id="cbtn-power-on" class="btn btn-primary btn-sm tmp-btn" >電源ON</button><br><span id="lastpon"></span></td>
    <td class="text-nowrap"><button id="cbtn-power-off" class="btn btn-primary btn-sm tmp-btn" >電源OFF</button><br><span id="lastpoff">　</span></td>
  </tr>
  <tr><td colspan="2"> </td></tr>
<?php if ($values['disp_remote1'] == 1) { ?>
  <tr>
    <td class="text-nowrap"><button id="cbtn-remote1-on" class="btn btn-primary btn-sm tmp-btn" >遠隔1 ON</button><br><span id="lastr1on"></span></td>
    <td class="text-nowrap"><button id="cbtn-remote1-off" class="btn btn-primary btn-sm tmp-btn" >遠隔1 OFF</button><br><span id="lastr1off"></span></td>
  </tr>
<?php } ?>
<?php if ($values['disp_remote2'] == 1) { ?>
  <tr>
    <td class="text-nowrap"><button id="cbtn-remote2-on" class="btn btn-primary btn-sm tmp-btn" >遠隔2 ON</button><br><span id="lastr2on"></span></td>
    <td class="text-nowrap"><button id="cbtn-remote2-off" class="btn btn-primary btn-sm tmp-btn" >遠隔2 OFF</button><br><span id="lastr2off"></span></td>
  </tr>
<?php } ?>
<?php if ($values['disp_remote_hst'] == 1) { ?>
  <tr>
    <td colspan="2">【遠隔履歴】<br><textarea id="remote_history" class="debugarea"></textarea></td>
  </tr>
<?php } ?>
</table>

    </td>
  </tr>
</table>
<form name="form1" id="form1" method="post" action="index.php">
  <input type="hidden" name="autodt" value="<?= $_POST["autodt"] ?>">
</form>

<!-- ----------------------------------------------------------- -->
<!-- ----------------------------------------------------------- -->
<script>
// UDP受信
const ajaxReceiveUDP = (n) => {
  let ip = $('#ip').val();
  let port = $('#port').val();
  let dgram = $('#dgram').val();
//  alert(ip + ":" + port + "=>" + dgram);
//  $('#Result').val("送信中です…");
//  return "<<" + n + ">>"+'\n';

  let data = { "ip" : ip, "port" : port, "dgram": dgram };
  let json = JSON.stringify(data);
  let xhr = new XMLHttpRequest();
  let ret = "";
  xhr.open("POST", "./ajax/ajaxReceiveUDP.php");
  xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded;charset=UTF-8");
  xhr.send(json);
  xhr.onreadystatechange = function () {
    try {
      if (xhr.readyState == 4 && xhr.status == 200) {
        var result = JSON.parse(xhr.response);
        ret = result.value == 0 ? "" : result.value;
        if (ret.length > 0) {
//          ret = ret + '\n';
          debugWrite(ret);
        }
        return "result.value";
      }
    } catch (e) {
    }
  };
};
</script>

<script>
// =============================================
var timer1 = null;
var cnt = 0;
// =============================================

/* *******************************************
SLEEP
******************************************* */
const sleep = waitTime => new Promise(resolve => setTimeout(resolve, waitTime));

const event = function () {
  cnt++;
  let inputVal = ajaxReceiveUDP(cnt);
//  ajaxSendUDP("<?= $values['cmd_info'] ?>");
//  sleep(2000).then(()=>{ ajaxDataUpdate(<?= $slot->id ?>); });
  ajaxGetHistory("lastpon", "<?= $slot->ip ?>", "P", "1"); // 最終電源ON
  ajaxGetHistory("lastpoff", "<?= $slot->ip ?>", "P", "0"); // 最終電源OFF
  ajaxGetHistory("lastr1on", "<?= $slot->ip ?>", "R1", "1"); // 最終電源ON
  ajaxGetHistory("lastr1off", "<?= $slot->ip ?>", "R1", "0"); // 最終電源OFF
  ajaxGetHistory("lastr2on", "<?= $slot->ip ?>", "R2", "1"); // 最終電源OFF
  ajaxGetHistory("lastr2off", "<?= $slot->ip ?>", "R2", "0"); // 最終電源OFF

  ajaxPutHistory("<?= $slot->ip ?>"); // 遠隔履歴
};

const startt = function () {
    timer1 = setInterval(event, 1500);
};

const debugWrite = function (str) {
  let dbg = $('#debug');
  dbg.val(dbg.val() + str);
  dbg.scrollTop(dbg[0].scrollHeight - dbg.height());
};


const readRemoteHistory = (fnm, elm) => {
  let xhr = new XMLHttpRequest();
  xhr.open('get', fnm);
  xhr.send();
  xhr.onreadystatechange = function() {
    if( xhr.readyState === 4 && xhr.status === 200) {
      $("#" + elm).val(this.responseText.replace(/\n/g, "\n"));
    }
  };
};

const ajaxPutHistory = (ip) => {
  let data = { "ip" : ip,  };
  let json = JSON.stringify(data);
  let xhr = new XMLHttpRequest();
  xhr.open("POST", "./ajax/ajaxPutHistory.php");
  xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded;charset=UTF-8");
  xhr.send(json);
  xhr.onreadystatechange = function () {
    try {
      if (xhr.readyState == 4 && xhr.status == 200) {
        let result = JSON.parse(xhr.response);
        let fnm = "<?= _HIST_PATH_REL ?>r_history_" + ip + ".txt";
        readRemoteHistory(fnm, "remote_history");
 //       setDataHome(id, result.value);
      } else {
      }
    } catch (e) {
    }
  };
};


const ajaxDataUpdate = (id, cmd) => {
  let data = { "id" : id, "cmd" : cmd };
  let json = JSON.stringify(data);
  let xhr = new XMLHttpRequest();
//  alert(id);
  xhr.open("POST", "./ajax/ajaxDataUpdate.php");
  xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded;charset=UTF-8");
  xhr.send(json);
  xhr.onreadystatechange = function () {
    try {
      if (xhr.readyState == 4 && xhr.status == 200) {
        let result = JSON.parse(xhr.response);
        setDataSlot(result.value);
      } else {
      }
    } catch (e) {
    }
  };
};

const setDataSlot = (data) => {
  let itemData = data.split(',');
  if (itemData.length == 7) {

    $("#cur_point").html(itemData[0]); // 現在PT
    $("#buy_point").html(itemData[1]); // 購入PT累計
    $("#cls_poinst").html(itemData[2]); // 清算PT累計
    // //////////////////////////////////////////////////////
    $("#inf_in").html(itemData[3]); // IN枚数
    $("#inf_out").html(itemData[4]); // OUT枚数
    let dif = itemData[3] - itemData[4]; // 差枚数
    $("#inf_dif").html(dif);
    if (dif < 0) {
        $('#inf_dif').addClass("text-danger");
    } else {
      $('#inf_dif').removeClass("text-danger");
    }
    $("#inf_big").html(itemData[5]); // BIG回数
    $("#inf_reg").html(itemData[6]); // REG回数
    $("#inf_sp").html("特"); // 特約回数
    $("#inf_pc").html(orgRound(itemData[3], itemData[4]) + "%"); // 機械割
  }
};

const orgRound = (inval, outval) => {
  if (inval == 0 && outval == 0) {
    return 0;
  }
  return Math.round(((outval / inval) * 100) * 10) / 10;
};

const makeCommand = (com, val) => {
  return com.replace('_?_', val);
};

const splitCommand = (com) => {
  let command = com.split(',');
  return command[0];
};


const ajaxReturnUDP = (ip, cmd, elm) => {
  let data = { "ip" : ip, "cmd" : cmd };
  let json = JSON.stringify(data);
  let xhr = new XMLHttpRequest();
  let ret = "";
  xhr.open("POST", "./ajax/ajaxReturnUDP.php");
  xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded;charset=UTF-8");
  xhr.send(json);
  xhr.onreadystatechange = function () {
    try {
      if (xhr.readyState == 4 && xhr.status == 200) {
        let result = JSON.parse(xhr.response);
        if (result.value == "") {
        $("#"+elm).val("- no res -");
//        $("#"+elm).hide();

        } else {
        $("#"+elm).val(result.value);
        }
      }
    } catch (e) {
    }
  };
};


const ajaxSendUDP = (ip, port, dgram) => {
  let data = { "ip" : ip, "port" : port, "dgram" : dgram};
  let json = JSON.stringify(data);
//  alert("ip=" + ip + " port=" + port + " dgram=" + dgram);
  let xhr = new XMLHttpRequest();
  xhr.open("POST", "./ajax/ajaxSendUDP.php");
  xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded;charset=UTF-8");
  xhr.send(json);
  xhr.onreadystatechange = function () {
    try {
      if (xhr.readyState == 4 && xhr.status == 200) {
        let result = JSON.parse(xhr.response);
 //       setData(id, result.value);
      } else {
      }
    } catch (e) {
    }
  };
};


const ajaxAddHistory = (ip, op, dir) => {
  let data = { "ip" : ip, "op" : op, "dir" : dir };
  let json = JSON.stringify(data);
  let xhr = new XMLHttpRequest();
//  alert(id);
  xhr.open("POST", "./ajax/ajaxAddHistory.php");
  xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded;charset=UTF-8");
  xhr.send(json);
  xhr.onreadystatechange = function () {
    try {
      if (xhr.readyState == 4 && xhr.status == 200) {
        let result = JSON.parse(xhr.response);
//        setData(id, result.value);
      } else {
      }
    } catch (e) {
    }
  };
};

const ajaxGetHistory = (elm, ip, op, dir) => {
  let data = { "ip" : ip, "op" : op, "dir" : dir };
  let json = JSON.stringify(data);
  let xhr = new XMLHttpRequest();
  xhr.open("POST", "./ajax/ajaxGetHistory.php");
  xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded;charset=UTF-8");
  xhr.send(json);
  xhr.onreadystatechange = function () {
    try {
      if (xhr.readyState == 4 && xhr.status == 200) {
        let result = JSON.parse(xhr.response);
        let ret =  result.value;
        if (ret.length > 0) {
          $('#' + elm).html(result.value);
        } else {
          $('#' + elm).html("- 履歴はありません -");
        }
      } else {
      }
    } catch (e) {
    }
  };
};


/* *******************************************
ONLOAD設定
******************************************* */
$(function() {
  $("#txt-seisan").hide();
  $("#txt-set").hide();
  $("#txt-reset").hide();
  ajaxSendUDP("<?= $values['cmd_info'] ?>");
  sleep(1000).then(()=>{ ajaxDataUpdate(<?= $slot->id ?>, splitCommand("<?= $values['cmd_info'] ?>")); });// $value["cmd_info"]
  ajaxGetHistory('lastpon', '<?= $slot->ip ?>','P','1');
  ajaxGetHistory('lastpoff', '<?= $slot->ip ?>','P','0');
  ajaxGetHistory("lastr1on", "<?= $slot->ip ?>", "R1", "1"); // 最終電源ON
  ajaxGetHistory("lastr1off", "<?= $slot->ip ?>", "R1", "0"); // 最終電源ON
  ajaxGetHistory("lastr2on", "<?= $slot->ip ?>", "R2", "1"); // 最終電源OFF
  ajaxGetHistory("lastr2off", "<?= $slot->ip ?>", "R2", "0"); // 最終電源OFF
  ajaxPutHistory("<?= $slot->ip ?>"); // 遠隔履歴
  startt(); // タイマー起動
  // 戻るボタン
  $("#btn-back").on('click', function () {
     $('#form1').submit();
  });
  // 清算ボタン
  $("#cbtn-seisan").on('click', function () {
/*
INSERT INTO setting (id, key, val, btn) VALUES (25, 'cmd_settlement', 'STL,0', '精算');
*/
    ajaxSendUDP("<?= $slot->ip ?>", <?= _PORT ?>, "<?= $values['cmd_settlement'] ?>"); // 1027
    swal("精算されました");
  });
  // 設定変更
  $("#cbtn-set").on('click', function () {
    let st = $("#sel-set").val();
    if (st == "0") {
      swal("設定を選択してください");
      return;
    } else {
    // 1027
    ajaxSendUDP("<?= $slot->ip ?>", <?= _PORT ?>, makeCommand("<?= $values['cmd_set_change'] ?>", st));
    swal("設定" + st + "に変更されました");
    $("#sel-set").val("0");
  }
  });
  // 設定確認
  $("#cbtn-set-conf").on('click', function () {
    ajaxSendUDP("<?= $slot->ip ?>", <?= _PORT ?>, "<?= $values['cmd_set_conf'] ?>");
    sleep(1000).then(()=>{   $("#txt-set").show();
ajaxReturnUDP("<?= $slot->ip ?>", splitCommand("<?= $values['cmd_set_conf'] ?>"), "txt-set"); });
  });
  // コイン53枚
  $("#cbtn-coin53").on('click', function () {
    ajaxSendUDP("<?= $slot->ip ?>", <?= _PORT ?>, makeCommand("<?= $values['cmd_coin'] ?>", '53'));
    swal("コイン53枚投入しました");
  });
  // オート開始
  $("#cbtn-auto-start").on('click', function () {
    ajaxSendUDP("<?= $slot->ip ?>", <?= _PORT ?>, "<?= $values['cmd_auto_start'] ?>");
    swal("オートを開始しました");
  });
  // オート停止
  $("#cbtn-auto-stop").on('click', function () {
    ajaxSendUDP("<?= $slot->ip ?>", <?= _PORT ?>, "<?= $values['cmd_auto_stop'] ?>");
    swal("オートを停止しました");
  });
  // リセット
  $("#cbtn-reset").on('click', function () {
    ajaxSendUDP("<?= $slot->ip ?>", <?= _PORT ?>, "<?= $values['cmd_reset'] ?>");
    sleep(1000).then(()=>{   $("#txt-reset").show();
ajaxReturnUDP("<?= $slot->ip ?>", splitCommand("<?= $values['cmd_reset'] ?>"), "txt-reset"); });
  });
  // データ読み出し　debug
 $("#cbtn-read-data").on('click', function () {
    ajaxSendUDP("<?= $slot->ip ?>", <?= _PORT ?>, "<?= $values['cmd_info'] ?>"); // 1027
//    ajaxSendUDP("<?= $values['cmd_info'] ?>");
    sleep(1500).then(()=>{ ajaxDataUpdate(<?= $slot->id ?>, splitCommand("<?= $values['cmd_info'] ?>")); });
    swal("データを読み出しました");
  });
  // ポイント購入 1027
  $("#cbtn-buy-point").on('click', function () {
    let bp = $("#sel-buy-point").val();
    if (bp == "0") {
      swal("購入するポイントを選択してください");
      return;
    } else {
      ajaxSendUDP("<?= $slot->ip ?>", <?= _PORT ?>, makeCommand("<?= $values['cmd_point'] ?>", bp));
      swal(bp + "ポイント購入しました");
      $("#sel-buy-point").val(0);
    }
  });
  // 単価設定
  $("#cbtn-point-setting").on('click', function () {
    let p = $("#txt-point-setting").val();
    if (p == "") {
      swal("設定する単価を入力してください");
      return;
    } else {
    $("#txt-point-setting").val("");
    swal("単価を" + p + "円に設定しました");
    $("#txt-point-setting").val("");
  }
  });
  // 電源ON
  $("#cbtn-power-on").on('click', function () {
    ajaxSendUDP("<?= $slot->ip ?>", <?= _PORT ?>, "<?= $values['cmd_power_on'] ?>");
    ajaxAddHistory("<?= $slot->ip ?>", "P", "1");
    swal("電源をONにしました");
  });
  // 電源OFF
  $("#cbtn-power-off").on('click', function () {
    ajaxSendUDP("<?= $slot->ip ?>", <?= _PORT ?>, "<?= $values['cmd_power_off'] ?>");
    ajaxAddHistory("<?= $slot->ip ?>", "P", "0");
    swal("電源をOFFにしました");
  });
  // 遠隔1ON
  $("#cbtn-remote1-on").on('click', function () {
    ajaxSendUDP("<?= $slot->ip ?>", <?= _PORT ?>, "<?= $values['cmd_remote1_on'] ?>");
    ajaxAddHistory("<?= $slot->ip ?>", "R1", "1");
  });
  // 遠隔1OFF
  $("#cbtn-remote1-off").on('click', function () {
    ajaxSendUDP("<?= $slot->ip ?>", <?= _PORT ?>, "<?= $values['cmd_remote1_off'] ?>");
    ajaxAddHistory("<?= $slot->ip ?>", "R1", "0");
  });
  // 遠隔2ON
  $("#cbtn-remote2-on").on('click', function () {
    ajaxSendUDP("<?= $slot->ip ?>", <?= _PORT ?>, "<?= $values['cmd_remote2_on'] ?>");
    ajaxAddHistory("<?= $slot->ip ?>", "R2", "1");
  });
  // 遠隔2OFF
  $("#cbtn-remote2-off").on('click', function () {
    ajaxSendUDP("<?= $slot->ip ?>", <?= _PORT ?>, "<?= $values['cmd_remote2_off'] ?>");
    ajaxAddHistory("<?= $slot->ip ?>", "R2", "0");
  });
});
</script>
<!--
<script src="./js/script.js"></script>
<script src="./js/slot.js"></script>
-->
</body>
</html>