<?php
?>
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="HandheldFriendly" content="True" />
  <title>ERROR</title>
  <link rel="icon" href="img/favicon.png" type="image/png">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://code.jquery.com/jquery-migrate-3.4.0.min.js" integrity="sha256-mBCu5+bVfYzOqpYyK4jm30ZxAZRomuErKEFJFIyrwvM=" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.6.1/js/iziModal.min.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.6.1/css/iziModal.css">
  <link href="https://use.fontawesome.com/releases/v6.2.0/css/all.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery.colorbox/1.4.31/example1/colorbox.css" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.colorbox/1.4.31/jquery.colorbox-min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.colorbox/1.4.31/i18n/jquery.colorbox-ja.js"></script>
  <link rel="stylesheet" href="./css/style.css" media="screen">
  <style>
 @import url('https://fonts.googleapis.com/css?family=Cabin+Sketch');

html {
  height: 100%;
}

body {
  min-height: 100%;
}

body {
  display: flex;
}

h1 {
  font-family: 'Cabin Sketch', cursive;
  font-size: 3em;
  text-align: center;
  opacity: .8;
  order: 1;
}

h1 small {
  display: block;
}

.site {
  display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display: flex;
  -webkit-box-align: center;
  -webkit-align-items: center;
  -ms-flex-align: center;
  align-items: center;
  flex-direction: column;
  margin: 0 auto;
  -webkit-box-pack: center;
  -webkit-justify-content: center;
  -ms-flex-pack: center;
  justify-content: center;
}


.sketch {
  position: relative;
  height: 400px;
  min-width: 400px;
  margin: 0;
  overflow: visible;
  order: 2;
  
}

.bee-sketch {
  height: 100%;
  width: 100%;
  position: absolute;
  top: 0;
  left: 0;
}

.red {
  background: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/198554/red-1.png) no-repeat center center;
  opacity: 1;
  animation: red 3s linear infinite, opacityRed 5s linear alternate infinite;
}

.blue {
  background: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/198554/blue-1.png) no-repeat center center;
  opacity: 0;
  animation: blue 3s linear infinite, opacityBlue 5s linear alternate infinite;
}


@media only screen and (min-width: 780px) {
  .site {
    flex-direction: row;
    padding: 1em 3em 1em 0em;
  }
  
  h1 {
    text-align: right;
    order: 2;
    padding-bottom: 2em;
    padding-left: 2em;

  }
  
  .sketch {
    order: 1;
  }
}


@keyframes blue {
  0% {
    background-image: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/198554/blue-1.png) 
  }
  9.09% {
    background-image: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/198554/blue-2.png) 
  }
  27.27% {
    background-image: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/198554/blue-3.png) 
  }
  36.36% {
    background-image: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/198554/blue-4.png) 
  }
  45.45% {
    background-image: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/198554/blue-5.png) 
  }
  54.54% {
    background-image: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/198554/blue-6.png) 
  }
  63.63% {
    background-image: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/198554/blue-7.png) 
  }
  72.72% {
    background-image: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/198554/blue-8.png) 
  }
  81.81% {
    background-image: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/198554/blue-9.png) 
  }
  100% {
    background-image: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/198554/blue-1.png) 
  }
}

@keyframes red {
  0% {
    background-image: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/198554/red-1.png) 
  }
  9.09% {
    background-image: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/198554/red-2.png) 
  }
  27.27% {
    background-image: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/198554/red-3.png) 
  }
  36.36% {
    background-image: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/198554/red-4.png) 
  }
  45.45% {
    background-image: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/198554/red-5.png) 
  }
  54.54% {
    background-image: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/198554/red-6.png) 
  }
  63.63% {
    background-image: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/198554/red-7.png) 
  }
  72.72% {
    background-image: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/198554/red-8.png) 
  }
  81.81% {
    background-image: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/198554/red-9.png) 
  }
  100% {
    background-image: url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/198554/red-1.png) 
  }
}

@keyframes opacityBlue {
  from {
    opacity: 0
  }
  25% {
    opacity: 0
  }
  75% {
    opacity: 1
  }
  to {
    opacity: 1
  }
}

@keyframes opacityRed {
  from {
    opacity: 1
  }
  25% {
    opacity: 1
  }
  75% {
    opacity: .3
  }
  to {
    opacity: .3
  }
}
</style>
</head>
<body>
<div class="site">
  <div class="sketch">
    <div class="bee-sketch red"></div>
    <div class="bee-sketch blue"></div>
  </div>
<h1>404:
  <small><a href="javascript:window.close();">Slot Not Found</a></small></h1>
</div>
</body>
</html>