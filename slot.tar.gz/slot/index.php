<?php
if (is_file(dirname(__FILE__).DIRECTORY_SEPARATOR."common.php")) { require_once(dirname(__FILE__).DIRECTORY_SEPARATOR."common.php"); }
if (is_file(dirname(__FILE__).DIRECTORY_SEPARATOR."config.php")) { require_once(dirname(__FILE__).DIRECTORY_SEPARATOR."config.php"); }
if (is_file('.'.DIRECTORY_SEPARATOR.'class'.DIRECTORY_SEPARATOR.'Slot.class.php')) { require_once('./'.DIRECTORY_SEPARATOR.'class'.DIRECTORY_SEPARATOR.'Slot.class.php'); }
$sb = new SlotBean();
$sb->where = "id>0";
$slots = $sb->getEntries();
?>
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="HandheldFriendly" content="True" />
  <title>SLOT</title>
  <link rel="icon" href="img/favicon.png" type="image/png">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://code.jquery.com/jquery-migrate-3.4.0.min.js" integrity="sha256-mBCu5+bVfYzOqpYyK4jm30ZxAZRomuErKEFJFIyrwvM=" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.6.1/js/iziModal.min.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.6.1/css/iziModal.css">
  <link href="https://use.fontawesome.com/releases/v6.2.0/css/all.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery.colorbox/1.4.31/example1/colorbox.css" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.colorbox/1.4.31/jquery.colorbox-min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.colorbox/1.4.31/i18n/jquery.colorbox-ja.js"></script>
  <link rel="stylesheet" href="./css/style.css" media="screen">
  <script> var ArrID = new Array();</script>
  <style>.onPlay { font-weight: 800;   color: red; } .offPlay { font-weight: 400;   color: black; } #cboxClose{ top:0; } /* colorbox の閉じるボタン */ #cboxLoadedContent{ padding-top:28px; }</style>

  <style>.memo { border: 0; font-size: 90%; color: #666; background-color:transparent;}</style>

</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
    <div id="navbarNav1">
      <ul class="navbar-nav">
        <li class="nav-item">　<button class="btn btn-danger btn-sm btn-top-navi" id="cbtn-clear">全台データクリア</button></li>
      </ul>
    </div>
    <div id="navbarNav2">
      <ul class="navbar-nav">
        <li class="nav-item">　<button class="btn btn-warning btn-sm btn-top-navi" id="cbtn-config"><i class="fa-solid fa-gear"> システム設定</i></button></li>
        <li class="nav-item">　<button class="btn btn-secondary btn-sm btn-top-navi" id="btn-logout"><i class="fa-solid fa-arrow-right-from-bracket"> ログアウト</i></button></li>
<?php if (_DEBUG == 1) { ?>
        <li class="nav-item">　<button class="btn btn-secondary btn-sm btn-top-navi" id="btn-debug"><i class="fa-solid fa-gear"> debug</i></button></li>
<?php } ?>
      </ul>
    </div>
  </div>
</nav>
<table class="table table-hover table-bordered table-striped" style="width:96%">
  <thead>
    <tr>
      <th><div class="text-center">台番+名前</div></th>
      <th><div class="text-center">INポイント</div></th>
      <th><div class="text-center">OUTポイント</div></th>
      <th><div class="text-center">差ポイント</div></th>
      <th><div class="text-center">BIG回数</div></th>
      <th><div class="text-center">REG回数</div></th>
      <th><div class="text-center">詳細</div></th>
      <th><div class="text-center">履歴</div></th>
      <th><div class="text-center">クリア</div></th>
    </tr>
  </thead>
  <tbody>
<?php $ct = 0; foreach($slots as $slot) { ?>
<?php 
  if ($slot->gkey == "") { 
    $cls = "offPlay"; 
  } else { 
    $cls = "onPlay"; 
  } 
?>
<script>  ArrID.push(<?= $slot->id ?>); </script>
    <tr class="align-middle">
      <td class="<?= $cls ?>"><?= '('.$slot->num.')'.$slot->name ?>
      　<input type="text" id="memo<?= $slot->id ?>" value="<?= $slot->memo ?>" class="memo"><!-- new -->
    </td><!-- td class="table-danger" -->
      <td><div id="col1-<?= $slot->id ?>" class="text-end"></div></td>
      <td><div id="col2-<?= $slot->id ?>" class="text-end"></div></td>
      <td><div id="col3-<?= $slot->id ?>" class="text-end"></div></td>
      <td><div id="col4-<?= $slot->id ?>" class="text-end"></div></td>
      <td><div id="col5-<?= $slot->id ?>" class="text-end"></div></td>
      <td>
        <div class="text-center">
<?php if ($slot->gkey == "") { ?>
          <a class="iframex1" href="./sw_game.php?id=<?= $slot->id ?>"><button class="btn btn-success btn-sm btn-top-slot"><i class="fa-solid fa-circle-dollar-to-slot"> 開始</i></button></a>
<?php } else { ?>
          <a class="iframex1" href="./sw_game.php?id=<?= $slot->id ?>"><button class="btn btn-danger btn-sm btn-top-slot"><i class="fa-solid fa-check-to-slot"> 終了</i></button></a>
<?php }  ?>
        </div>
      </td>
      <td>
        <div class="text-center">
          <a class="iframex2" href="./sw_history.php?id=<?= $slot->id ?>"><button class="btn btn-info btn-sm btn-top-slot"><i class="fa-solid fa-file-lines"> 履歴</i></button></a>
        </div>      
      </td>
      <td>
        <div class="text-center">
<?php if ($slot->gkey == "") { ?>
          <a class="iframex3" href="./sw_clear.php?id=<?= $slot->id ?>"><button class="btn btn-danger btn-sm btn-top-slot"><i class="fa-solid fa-circle-check"></i></button></a>
<?php } else { ?>
          <button disabled class="btn btn-danger btn-sm btn-top-slot"><i class="fa-solid fa-circle-check"></i></button>
<?php }  ?>
        </div>
      </td>
<?php $ct++; } ?>
  </tbody>
</table>
<input type="hidden" id="gkey">
<iframe id="result" width="100%" height="40"></iframe>
<iframe id="api-result" style="display: none;"></iframe>
<!-- debug -------------------------------------------- -->
<div id="debugarea" style="display:none;">
<div>
<select id="sel">
<?php foreach($slots as $slot) { ?>
  <option value="<?= $slot->ip ?>">(<?= $slot->num ?>)<?= $slot->name ?>(<?= $slot->ip ?>)</option>
<?php } ?>
</select><span>　</span>
<button id="start">START</button>
</div>
<br>
<div><iframe id="game" width="100%" height="300"></iframe></div>
<div><iframe id="webiopi" style="display:none;"></iframe></div>
</div>
<form id="frm-config" name="frm-config" action="./index3.php" method="post"></form>
<form id="frm-logout" name="frm-logout" action="./logout.php" method="post"></form>
<script>
const sleep = waitTime => new Promise(resolve => setTimeout(resolve, waitTime));
const getPort = (ip) => { return "<?= _PORT_PREFIX ?>" + ip.split('.')[3]; };
var debug1 = 0;

const ajaxClearData = (id) => {
  let data = { "id" : id,};
  let json = JSON.stringify(data);
  let xhr = new XMLHttpRequest();
  xhr.open("POST", "./ajax/ajaxClearData.php");
  xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded;charset=UTF-8");
  xhr.send(json);
  xhr.onreadystatechange = function () {
    try {
      if (xhr.readyState == 4 && xhr.status == 200) {
        let result = JSON.parse(xhr.response);
        $("#gkey").val(result.value);
      } else {
      }
    } catch (e) {
    }
  };
};

const ajaxGetGameData = (id) => {
  let data = { "id" : id };
  let json = JSON.stringify(data);
  let xhr = new XMLHttpRequest();
  xhr.open("POST", "./ajax/ajaxGetGameData.php");
  xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded;charset=UTF-8");
  xhr.send(json);
  xhr.onreadystatechange = function () {
    try {
      if (xhr.readyState == 4 && xhr.status == 200) {
        let result = JSON.parse(xhr.response);
        setDataHome(id, result.value);
      } else {
      }
    } catch (e) {
    }
  };
};

const setDataHome = (id, data) => {
  let itemData = data.split(',');
  if (itemData.length === 4) { // CSVのサイズ
    $('#col1-' + id).html(itemData[0]); // IN枚数
    $('#col2-' + id).html(itemData[1]); // OUT枚数
    let diff = itemData[0] - itemData[1];
    if (diff < 0) { $('#col3-' + id).addClass("text-danger"); } else { $('#col3-' + id).removeClass("text-danger"); }
    $('#col3-' + id).html(diff); // 差枚数
    $('#col4-' + id).html(itemData[2]); // BIG回数
    $('#col5-' + id).html(itemData[3]); // REG回数
  }
};

const _ajaxDataUpdate = () => {
  for (let i = 0; i < ArrID.length; i++) {
    ajaxGetGameData(ArrID[i]);
  }
};

function updateMemo() { return ajaxMemo((this.id).replace('memo', ''), $('#' + this.id).val()); }
const ajaxMemo = (id, memo) => {
  let data = { "id" : id, "memo" : memo,};
  let json = JSON.stringify(data);
  let xhr = new XMLHttpRequest();
  xhr.open("POST", "./ajax/ajaxMemo.php");
  xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded;charset=UTF-8");
  xhr.send(json);
  xhr.onreadystatechange = function () {
    try {
      if (xhr.readyState == 4 && xhr.status == 200) {
        let result = JSON.parse(xhr.response);
        $("#gkey").val(result.value);
      } else {
      }
    } catch (e) {
    }
  };
};

// debug
const debug = () => {
  let ip = $("#sel").val();
  let url = "http://" + ip + ":" + getPort(ip) + "/api/webiopi.html?point=10&gkey=24235678bjhu&macro=check";
  $("#webiopi").attr("src", url);
  sleep(1000).then(()=>{ 
    url = "http://" + ip + ":" + getPort(ip) + "/api/game.json";
    $("#game").attr("src", url);
  });
};
/* *******************************************
ONLOAD設定
******************************************* */
$(function() {
  $(".iframex1").colorbox({iframe:true, width:"45%", height:"65%"}); // 開始・終了
  $(".iframex2").colorbox({iframe:true, width:"85%", height:"90%"}); // 履歴
  $(".iframex3").colorbox({iframe:true, width:"40%", height:"65%"}); // クリア
  _ajaxDataUpdate();
  $("#cbtn-clear").on('click', function () {
    swal({
      title: "データクリアを実行しますか?",
      text: "全台のデータをクリアします。取り消しできません!",
      icon: "warning",
      buttons: ['中止', 'データクリア実行'],
      dangerMode: true,
    }).then(function(isConfirm) {
      if (isConfirm) {
        swal({
          title: '処理を実行しました!',
          text: 'データはクリアされました!',
          icon: 'success'
        }).then(function() {
          for (let i =0; i < ArrID.length; i++) {
            ajaxClearData(ArrID[i]);
          }
          sleep(500).then(()=>{ location.reload(); });
        });
      } else {
        swal("中止しました", "すべてのデータは安全です", "error");
      }
    })
  });
<?php foreach($slots as $slot) { ?>
  $('#memo<?= $slot->id ?>').blur(updateMemo);
<?php } ?>
  // システム設定
  $("#cbtn-config").on('click', function () {
    $('#frm-config').submit();
  });
  // ログアウト
  $("#btn-logout").on('click', function () {
    $('#frm-logout').submit();
  });
  // debug
  $("#btn-debug").on('click', function () {
    if (debug1 == 0) {
      $("#debugarea").css("display" , "inline");
    } else {
      location.reload();
    }
  });
  $("#start").on('click', function () {
    debug1 = setInterval('debug()',1000);
  }); 
});
</script>
</body>
</html>