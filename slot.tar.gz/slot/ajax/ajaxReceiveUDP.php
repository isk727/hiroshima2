<?php
if (is_file('../class/Udp.class.php')) { require_once('../class/Udp.class.php'); }
$ub = new UdpBean();
$ub->where = "df=0"; // デバッグフラグ
$udp = $ub->getEntries();
$ret = "";
foreach ($udp as $dg) {
    $ret .= $dg->fm."(".$dg->pt.")>".$dg->ud."\n";
    $ub->setFlag($dg->id, "df");
}
$result =[ "value" => $ret, ];
$json = json_encode($result, JSON_UNESCAPED_UNICODE);
header("Content-Type: application/json; charset=UTF-8");
echo $json;
exit;
?>
