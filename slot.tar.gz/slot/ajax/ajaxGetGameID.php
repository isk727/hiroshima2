<?php
if (is_file('..' . DIRECTORY_SEPARATOR . 'class' . DIRECTORY_SEPARATOR . 'Json.class.php')) { require_once('..' . DIRECTORY_SEPARATOR . 'class' . DIRECTORY_SEPARATOR . 'Json.class.php'); }
$req = json_decode(file_get_contents("php://input"), true);
$sid = $req['sid'];
date_default_timezone_set('Asia/Tokyo');
$ret = date("YmdHis") . str_pad($sid, 3, 0, STR_PAD_LEFT) . str_pad(rand(1, 999), 3, 0, STR_PAD_LEFT);
$result =[ "gid" => $ret,];
//$result =[ "gid" => "678"];
$json = json_encode($result, JSON_UNESCAPED_UNICODE);
header("Content-Type: application/json; charset=UTF-8");
echo $json;
exit;
?>
