<?php
function recv() {
  error_reporting(E_ALL | E_STRICT);
  $socket = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);
  socket_bind($socket, '0.0.0.0', 50000);
  $from = '';
  $port = 0;
  ini_set('max_execution_time', 5);// whileは5秒で終了
  while (1) {
    socket_recvfrom($socket, $buf, 12, 0, $from, $port);
    echo "リモートアドレス $from のポート $port から $buf を受信しました" . PHP_EOL;
  }
}
//recv();



$req = json_decode(file_get_contents("php://input"), true);
$socket = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);
socket_sendto($socket, $req['dgram'], strlen($req['dgram']), 0, $req['ip'], $req['port']);
socket_close($socket);






// 応答処理
$ret = $req['ip'].":".$req['port'].">".$req['dgram'];
$result =[ "value" => $ret, ];
$json = json_encode($result, JSON_UNESCAPED_UNICODE);
header("Content-Type: application/json; charset=UTF-8");
echo $json;
exit;
?>
