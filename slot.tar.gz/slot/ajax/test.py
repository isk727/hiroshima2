#!/usr/local/bin/python3
# -*- coding: utf-8 -*-
#print("content-Type: text/plain\n")

import cgi

storage = cgi.FieldStorage()
print('Status: 200 OK')
print('Content-Type: text/html\n')
data = storage.getvalue('data')
recieve = data + ":Success!"
print(recieve)