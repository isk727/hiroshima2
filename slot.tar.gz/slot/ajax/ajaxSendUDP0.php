<?php
$ip = $_POST['ip'];
$port = $_POST['port'];
$dgram = $_POST['dgram'];
$socket = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP);
socket_sendto($socket, $dgram, strlen($dgram), 0, $ip, $port);
socket_close($socket);

$json = "{\"result\":\"$dgram\"}";
header("Content-Type: application/json; charset=UTF-8");
echo $json;
exit;
?>
