<?php
//if (is_file('../class/Game.class.php')) { require_once('../class/Game.class.php'); }
$req = json_decode(file_get_contents("php://input"), true);

$r = exec(sprintf('ping -c 1 -W 5 %s', escapeshellarg($req['host'])), $res, $rval);
$ret = ($rval === 0 ? 1 : 0);

//$gb = new GameBean();
//$ret = $gb->addGame($req['id'], $req['point']);
$result =[ "value" => $ret, ];
$json = json_encode($result, JSON_UNESCAPED_UNICODE);
header("Content-Type: application/json; charset=UTF-8");
echo $json;
exit;


/*
function ping($host) {
  $r = exec(sprintf('ping -c 1 -W 5 %s', escapeshellarg($host)), $res, $rval);
  return $rval === 0;
}

$host = '192.168.1.205';
$up = ping($host);
echo $up ? '正常稼働中' : '応答なし';

*/
?>
