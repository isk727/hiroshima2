<?php
if (is_file('../config.php')) { require_once('../config.php'); }
if (is_file('../class/History.class.php')) { require_once('../class/History.class.php'); }
$req = json_decode(file_get_contents("php://input"), true);

$hb = new HistoryBean();
$filename = _HIST_PATH_ABS."r_history_".$req['ip'].".txt";
//$filename = "/Library/WebServer/Documents/test3/hst/r_history_".$req['ip'].".txt";
$fp = fopen($filename, 'w');
$hb->where = "ip='".$req['ip']."' and (op='R1' or op='R2')";
$history = $hb->getEntries();
foreach($history as $hst) {
  $data = ($hst->op == "R1" ? "遠隔1" : "遠隔2")." ".($hst->dir == 1 ? "ON" : "OFF")." ".$hst->fdt."\n";
  fputs($fp, $data);
}
fclose($fp);

$ret = "789";
$json = "{\"result\":\"$ret\"}";
header("Content-Type: application/json; charset=UTF-8");
echo $json;
exit;
?>
