<?php
if (is_file('../class/Game.class.php')) { require_once('../class/Game.class.php'); }
//    public function addGame($sid, $point) {
$gb = new GameBean();
$req = json_decode(file_get_contents("php://input"), true);
//$ret = $gb->addGame('1', '192.168.1.206', 3456);

$ret = $gb->addGame($req['id'], $req['ip'], $req['point']);
//$ret = "青春";
$result =[ "value" => $ret, ];
$json = json_encode($result, JSON_UNESCAPED_UNICODE);
header("Content-Type: application/json; charset=UTF-8");
echo $json;
exit;
?>
