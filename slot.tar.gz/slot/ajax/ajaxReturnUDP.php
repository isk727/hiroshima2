<?php
if (is_file('../class/Udp.class.php')) { require_once('../class/Udp.class.php'); }
$req = json_decode(file_get_contents("php://input"), true);
$ip = $req['ip'];
$cmd = $req['cmd'].",";
$ub = new UdpBean();
$ub->where = "fm='".$ip."' and ud like '".$cmd."%' and fg=0";
$udp = $ub->getEntries();
$val = "";
foreach ($udp as $dg) {
    $val = str_replace($cmd, "", $dg->ud);
    $ub->setFlag($dg->id, "fg");
}
$result =[ "value" => $val, ];
$json = json_encode($result, JSON_UNESCAPED_UNICODE);
header("Content-Type: application/json; charset=UTF-8");
echo $json;
exit;
?>
