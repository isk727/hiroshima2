<?php
if (is_file('../class/Udp.class.php')) { require_once('../class/Udp.class.php'); }
function DoSomething() {
    $ub = new UdpBean();
    $ub->where = "fg=0";
    $udp = $ub->getEntries();
    $ret = "";
    $key = "RINFO"
    foreach ($udp as $dg) {
        $data = explode(",", $dg->ud);
        if ($data[0] == $key) {
//        if ($data[0] == $key && count($data) > 8) {
//            $sb->updateData($ip, $data);
        }
//        $ret .= $dg->dt." from=".$dg->fm." ==>[".$dg->ud."]\\n"; // jsonの改行は "\\n"
        $ret .= $dg->fm."(".$dg->pt.")>".$dg->ud."\\n"; // jsonの改行は "\\n"
        $ub->setFlag($dg->id);
    }
    return $ret;
}
$ip = $_POST['ip'];
$ret = DoSomething();
$json = "{\"result\":\"$ret\"}";
header("Content-Type: application/json; charset=UTF-8");
echo $json;
exit;
?>
