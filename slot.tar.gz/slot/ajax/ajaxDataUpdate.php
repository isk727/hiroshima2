<?php
if (is_file('../class/Slot.class.php')) { require_once('../class/Slot.class.php'); }
if (is_file('../class/Udp.class.php')) { require_once('../class/Udp.class.php'); }
$req = json_decode(file_get_contents("php://input"), true);
$sb = new SlotBean();
$sb->where = "id=".$req['id'];
$cmd = $req['cmd'];
$slot = $sb->getEntries();
if (count($slot) == 1) {
    $ub = new UdpBean();
    $ub->where = "fm='".$slot[0]->ip."' and fg=0 and ud like '".$cmd.",%'";
    $udp = $ub->getEntries();
    foreach($udp as $dg) {
        $arr = explode(",", $dg->ud);
        $sb->updateData($slot[0]->ip, $arr);
        $ub->setFlag($dg->id, "fg");
    }
    $val = $slot[0]->getCSV();
}
$result =[ "value" => $val, ];
$json = json_encode($result, JSON_UNESCAPED_UNICODE);
header("Content-Type: application/json; charset=UTF-8");
echo $json;
exit;
?>
