<?php
if (is_file('..' . DIRECTORY_SEPARATOR . 'class' . DIRECTORY_SEPARATOR . 'Game.class.php')) { require_once('..' . DIRECTORY_SEPARATOR . 'class' . DIRECTORY_SEPARATOR . 'Game.class.php'); }
$req = json_decode(file_get_contents("php://input"), true);
$gb = new GameBean();
$json = $gb->getJaonData($req['ip']);
$ret = $req['ip'] . " empty";
if (count($json) > 0) {
  $ret = $gb->formatDate($json['start_at']).','.$json['start_pt'].','.$json['credit'].','.$json['rb'].','.$json['bb'];
}
$result =[ "value" => $ret, ];
$json = json_encode($result, JSON_UNESCAPED_UNICODE);
header("Content-Type: application/json; charset=UTF-8");
echo $json;
exit;
?>
