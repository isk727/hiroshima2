<?php
if (is_file('../class/User.class.php')) { require_once('../class/User.class.php'); }
$ub = new UserBean();
$req = json_decode(file_get_contents("php://input"), true);
if ($req['com'] == "ADD") {
    // 登録済みチェック
}
$ret = $ub->modUser($req['com'], $req['id'], $req['userid'], $req['name'], $req['password'], $req['admin']);
//$ret = "789";
$result =[ "value" => $ret, ];
$json = json_encode($result, JSON_UNESCAPED_UNICODE);
header("Content-Type: application/json; charset=UTF-8");
echo $json;
exit;
?>
