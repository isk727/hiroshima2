<?php
if (is_file('../class/Slot.class.php')) { require_once('../class/Slot.class.php'); }
$sb = new SlotBean();
$req = json_decode(file_get_contents("php://input"), true);
$ret = $sb->modMemo($req['id'], $req['memo']);
$result =[ "value" => $ret, ];
$json = json_encode($result, JSON_UNESCAPED_UNICODE);
header("Content-Type: application/json; charset=UTF-8");
echo $json;
exit;
?>
