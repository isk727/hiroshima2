<?php
$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);

// サーバに接続
$address = '192.168.1.205';
$port = 8014;
$result = socket_connect($socket, $address, $port);

if ($result === false) {
    echo "socket_connect() failed.\n";
    exit;
}

// ソケット通信の処理...

// ソケットをクローズ
socket_close($socket);
?>