<?php
if (is_file('../class/Slot.class.php')) { require_once('../class/Slot.class.php'); }

//st ajaxChangeGameStatus = (id, game) => {
//changeGame($id, $game) {

$sb = new SlotBean();
$req = json_decode(file_get_contents("php://input"), true);
$result =[ "value" => $sb->changeGame($req['id'], $req['game']), ];
$json = json_encode($result, JSON_UNESCAPED_UNICODE);
header("Content-Type: application/json; charset=UTF-8");
echo $json;
exit;
?>
