<?php
if (is_file('../class/Setting.class.php')) { require_once('../class/Setting.class.php'); }
$sb = new SettingBean();
$req = json_decode(file_get_contents("php://input"), true);
$result =[ "value" => $sb->saveKeyValue($req['key'], $req['val']), ];
//saveKeyValue($key, $val)
$json = json_encode($result, JSON_UNESCAPED_UNICODE);
header("Content-Type: application/json; charset=UTF-8");
echo $json;
exit;
?>
