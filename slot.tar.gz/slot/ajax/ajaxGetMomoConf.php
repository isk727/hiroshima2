<?php
if (is_file('..' . DIRECTORY_SEPARATOR . 'class' . DIRECTORY_SEPARATOR . 'Json.class.php')) { require_once('..' . DIRECTORY_SEPARATOR . 'class' . DIRECTORY_SEPARATOR . 'Json.class.php'); }
$req = json_decode(file_get_contents("php://input"), true);
$url = "http://" . $req['ip']. ":" . $req['port'] . "/rec/output.json";
$json = (new Json())->getJson($url);
$result =[ "aaa" => $json['aaa'], "bbb" => $json['bbb']];
$json = json_encode($result, JSON_UNESCAPED_UNICODE);
header("Content-Type: application/json; charset=UTF-8");
echo $json;
exit;
?>
