<?php
if (is_file('..' . DIRECTORY_SEPARATOR . 'class' . DIRECTORY_SEPARATOR . 'Json.class.php')) { require_once('..' . DIRECTORY_SEPARATOR . 'class' . DIRECTORY_SEPARATOR . 'Json.class.php'); }
$req = json_decode(file_get_contents("php://input"), true);
//$url = "http://192.168.1.206:5206/rec/stop.json";
$url = "http://" . $req['ip']. ":" . $req['port'] . "/rec/game.json";
$json = (new Json())->getJson($url);
$result =[ "gkey" => $json['gkey'], "point" => $json['point'], "rbCount" => $json['rbCount'], "stop_at" => $json['stop_at']];
$json = json_encode($result, JSON_UNESCAPED_UNICODE);
header("Content-Type: application/json; charset=UTF-8");
echo $json;







exit;





?>
