<?php
if (is_file('../class/Game.class.php')) { require_once('../class/Game.class.php'); }
$req = json_decode(file_get_contents("php://input"), true);
$gb = new GameBean();
$ret = $gb->addGame($req['id'], $req['ip'], $req['point']);
$result =[ "value" => $ret, ];
$json = json_encode($result, JSON_UNESCAPED_UNICODE);
header("Content-Type: application/json; charset=UTF-8");
echo $json;
exit;
?>
