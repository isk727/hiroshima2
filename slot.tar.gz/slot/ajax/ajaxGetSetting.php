<?php
if (is_file('../class/Udp.class.php')) { require_once('../class/Udp.class.php'); }

if (is_file('../class/History.class.php')) { require_once('../class/History.class.php'); }


$req = json_decode(file_get_contents("php://input"), true);
$ub = new UdpBean();
$hst = $b->getLastUpdate($req['ip'], $req['op'], $req['dir']);




$hb = new HistoryBean();
$hst = $hb->getLastUpdate($req['ip'], $req['op'], $req['dir']);
$ret = "";
if (count($hst) > 0) {
    $ret = $hst[0]->fdt;
}
//$history = $hst[0];

//$hb->addHistory($req['ip'], $req['op'], $req['dir']);
//$ret = "90";//$history->fdt;

$result =[ "value" => $ret, ];
$json = json_encode($result, JSON_UNESCAPED_UNICODE);

//$json = "{\"result\":\"$ret\"}";
header("Content-Type: application/json; charset=UTF-8");
echo $json;
exit;
?>
