<?php
if (is_file('../class/History.class.php')) { require_once('../class/History.class.php'); }
$req = json_decode(file_get_contents("php://input"), true);
$hb = new HistoryBean();
$hb->addHistory($req['ip'], $req['op'], $req['dir']);
$ret = "789";
$json = "{\"result\":\"$ret\"}";
header("Content-Type: application/json; charset=UTF-8");
echo $json;
exit;
?>
