<?php
if (is_file('../class/Slot.class.php')) { require_once('../class/Slot.class.php'); }
$sb = new SlotBean();
$req = json_decode(file_get_contents("php://input"), true);
$ret = $sb->modSlot($req['com'], $req['id'], $req['name'], $req['ip'], $req['num']);
$result =[ "value" => $ret, ];
$json = json_encode($result, JSON_UNESCAPED_UNICODE);
header("Content-Type: application/json; charset=UTF-8");
echo $json;
exit;
?>
