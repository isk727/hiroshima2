<?php
if (is_file('./class/User.class.php')) { require_once('./class/User.class.php'); }
$ub = new UserBean();
$ub->where = "id=".$_GET['id'];;
$users = $ub->getEntries();
if (count($users) == 1) {
  $add = 0;
  $user = $users[0];
} else {
  $add = 1;
}

?>
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="HandheldFriendly" content="True" />
  <title>USER</title>
  <link rel="icon" href="img/favicon.png" type="image/png">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://code.jquery.com/jquery-migrate-3.4.0.min.js" integrity="sha256-mBCu5+bVfYzOqpYyK4jm30ZxAZRomuErKEFJFIyrwvM=" crossorigin="anonymous"></script>
  <!-- validate -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.6.1/js/iziModal.min.js"></script>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <!-- JSファイル読み込み -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.6.1/css/iziModal.css">
  <link rel="stylesheet" href="./css/style.css" media="screen">
</head>
<body>
<input id="txt-id" type="hidden" value="<?= $user->id ?>">
<input id="txt-password1" type="hidden" value="<?= $user->password ?>">
<table style="margin-left:2em;">
  <tr>
    <td>
      <div class="input-group mb-3">
      <span class="input-group-text" id="inputGroup-sizing-default">ユーザー名</span>
      <input type="text" id="txt-name" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?= $user->name ?>">
      </div>
    </td>
  </tr>

  <tr>
    <td>
      <div class="input-group mb-3">
      <span class="input-group-text" id="inputGroup-sizing-default">ログインID</span>
      <input type="text" id="txt-userid" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?= $user->userid ?>">
      </div>
    </td>
  </tr>

  <tr>
    <td>
      <div class="input-group mb-3">
      <span class="input-group-text" id="inputGroup-sizing-default">パスワード</span>
      <input type="text" id="txt-password" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default">
      </div>
    </td>
  </tr>
  <tr>
    <td>
      <div class="input-group mb-3">
        <div class="input-group-prepend">
          <label class="input-group-text" for="inputGroupSelect01">種別</label>
        </div>
        <select class="custom-select" id="inputGroupSelect01">
        <option value="0"<?= ($user->admin == 0 ? ' selected' : '') ?>>一般ユーザー</option>
        <option value="1"<?= ($user->admin == 1 ? ' selected' : '') ?>>管理者</option>
        </select>
      </div>
    </td>
  </tr>
<tr><td>
<button id="btn-add" class="btn btn-primary btn-sm buttonlg">登　録  </button>
<button id="btn-upd" class="btn btn-primary btn-sm buttonlg">更　新  </button>
<button id="btn-del" class="btn btn-danger btn-sm buttonlg">削　除  </button>
<button id="btn-close" class="btn btn-secondary btn-sm buttonlg">閉じる  </button>
</td></tr>
</table>
<div id="UPD_USER"></div>

<script>
var add = "<?= $add ?>";

const winClose = () => {
  open('about:blank', '_self').close();
};

const saveUser = (com) => {
  let uid = $('#txt-id').val();
  let uname = $('#txt-name').val();
  let uuserid = $('#txt-userid').val();
  let upassword = $('#txt-password').val();
  let uadmin = $('#inputGroupSelect01').val();
  ajaxUser(com, uid, uname, uuserid, upassword, uadmin);
};

const ajaxUser = (com, uid, uname, uuserid, upassword, uadmin) => {
  let data = { "com" : com, "id" : uid, "name" : uname, "userid" : uuserid, "password" : upassword, "admin" : uadmin };
  let json = JSON.stringify(data);
  let xhr = new XMLHttpRequest();
  xhr.open("POST", "./ajax/ajaxUser.php");
  xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded;charset=UTF-8");
  xhr.send(json);
  xhr.onreadystatechange = function () {
    try {
      if (xhr.readyState == 4 && xhr.status == 200) {
        let result = JSON.parse(xhr.response);
        $("#UPD_USER").html(result.value);
        open('about:blank', '_self').close();
        winClose();
//        setData(id, result.value);
      } else {
        $("#UPD_USER").html("result.value");
      }
    } catch (e) {
    }
  };
};

$(function() {
  if (add == 1) {
    $("#btn-upd").hide();
    $("#btn-del").hide();
  } else {
    $("#btn-add").hide();
  }
  $("#btn-add").on('click', function () { // 登録
    saveUser("ADD");
  });
  $("#btn-upd").on('click', function () { // 更新
    saveUser("UPD");
  });
  $("#btn-del").on('click', function () { // 削除
    swal({
      title: "実行しますか?",
      text: "このユーザーを削除します。取り消しはできません!",
      icon: "warning",
      buttons: ['中止', '削除実行'],
      dangerMode: true,
    }).then(function(isConfirm) {
      if (isConfirm) {
        swal({
          title: '処理を実行しました!',
          text: 'ユーザーは削除されました!',
          icon: 'success'
        }).then(function() {
          saveUser("DEL");
        });
      } else {
        swal("中止しました", "すべてのデータは安全です", "error");
      }
    })



//    saveUser("DEL");
  });
  $("#btn-close").on('click', function () { // 閉じる
    winClose();
  });
});
</script>
</body>
</html>