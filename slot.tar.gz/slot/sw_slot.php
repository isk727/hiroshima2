<?php
if (is_file('./class/Slot.class.php')) { require_once('./class/Slot.class.php'); }
$slb = new SlotBean();
if ($_GET['id'] == '0') {
  $add = 1;
  $slot = null;
} else {
  $slb->where = "id=".$_GET['id'];
  $slots = $slb->getEntries();
  if (count($slots) == 1) {
    $add = 0;
    $slot = $slots[0];
  }
}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="HandheldFriendly" content="True" />
  <title>SLOT</title>
  <link rel="icon" href="img/favicon.png" type="image/png">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://code.jquery.com/jquery-migrate-3.4.0.min.js" integrity="sha256-mBCu5+bVfYzOqpYyK4jm30ZxAZRomuErKEFJFIyrwvM=" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.6.1/js/iziModal.min.js"></script>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <!-- JSファイル読み込み -->
  <link href="https://use.fontawesome.com/releases/v6.2.0/css/all.css" rel="stylesheet">
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.6.1/css/iziModal.css">
  <link rel="stylesheet" href="./css/style.css" media="screen">
</head>
<body>
<input id="txt-id" type="hidden" value="<?= (is_null($slot) ? '' : $slot->id) ?>">
<table style="margin-left:2em;">
	<tr>
    <td>
      <div class="input-group mb-3">
      <span class="input-group-text" id="inputGroup-sizing-default">番号</span>
      <input type="number" id="txt-num" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?= (is_null($slot) ? '' : $slot->num) ?>"  required>
      </div>
    </td>
  </tr>
  <tr>
    <td>
      <div class="input-group mb-3">
      <span class="input-group-text" id="inputGroup-sizing-default">機種名</span>
      <input type="text" id="txt-name" class="form-control" style="width:30em;" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?= (is_null($slot) ? '' : $slot->name) ?>" required>
      </div>
    </td>
  </tr>
  <tr>
    <td>
      <div class="input-group mb-3">
      <span class="input-group-text" id="inputGroup-sizing-default">IPアドレス</span>
      <input type="text" id="txt-ip" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" value="<?= (is_null($slot) ? '' : $slot->ip) ?>" pattern="\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}" placeholder="000.000.000.000" required>
      </div>
    </td>
  </tr>
<tr><td>
<button id="btn-add" class="btn btn-primary btn-sm btn-top-navi">登　録  </button>
<button id="btn-upd" class="btn btn-primary btn-sm btn-top-navi">更　新  </button>
<button id="btn-del" class="btn btn-danger btn-sm btn-top-navi">削　除  </button>
<button id="btn-close" class="btn btn-secondary btn-sm btn-top-navi"><i class="fa-regular fa-circle-xmark"> 閉じる</i></button>
</td></tr>
</table>

<div id="UPD_SLOT"></div>

<script>
var add = "<?= $add ?>";

const winClose = () => {
  open('about:blank', '_self').close();
};

const saveSlot = (com) => {
  let sid = $('#txt-id').val();
  let sname = $('#txt-name').val();
  let sip = $('#txt-ip').val();
  let snum = $('#txt-num').val();
//  let com = "UPD"; // ADD | UPD | DEL
  ajaxSlot(com, sid, sname, sip, snum);
};

const ajaxSlot = (com, sid, sname, sip, snum) => {
  let data = { "com" : com, "id" : sid, "name" : sname, "ip" : sip, "num" : snum };
  let json = JSON.stringify(data);
  let xhr = new XMLHttpRequest();
  xhr.open("POST", "./ajax/ajaxSlot.php");
  xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded;charset=UTF-8");
  xhr.send(json);
  xhr.onreadystatechange = function () {
    try {
      if (xhr.readyState == 4 && xhr.status == 200) {
        let result = JSON.parse(xhr.response);
        $("#UPD_SLOT").html(result.value);
//        open('about:blank', '_self').close();
        winClose();
//        setData(id, result.value);
      } else {
      }
    } catch (e) {
    }
  };
};

$(function() {
  if (add == 1) {
    $("#btn-upd").hide();
    $("#btn-del").hide();
  } else {
    $("#btn-add").hide();
  }
  $("#btn-add").on('click', function () { // 登録
    if ($('#txt-num').val() == "") {
      swal("番号を入力してください");
      return false;
    }
    if ($('#txt-name').val() == "") {
      swal("機種名を入力してください");
      return false;
    }
    if ($('#txt-ip').val() == "") {
      swal("IPアドレスを入力してください");
      return false;
    }
    saveSlot("ADD");
  });
  $("#btn-upd").on('click', function () { // 更新
    saveSlot("UPD");
  });
  $("#btn-del").on('click', function () { // 削除
    swal({
      title: "実行しますか?",
      text: "この台を削除します。取り消しはできません!",
      icon: "warning",
      buttons: ['中止', '削除実行'],
      dangerMode: true,
    }).then(function(isConfirm) {
      if (isConfirm) {
        swal({
          title: '処理を実行しました!',
          text: '削除されました!',
          icon: 'success'
        }).then(function() {
          saveSlot("DEL");
        });
      } else {
        swal("中止しました", "すべてのデータは安全です", "error");
      }
    })
  });
  $("#btn-close").on('click', function () { // 閉じる
    winClose();
  });
});
</script>
</body>
</html>
