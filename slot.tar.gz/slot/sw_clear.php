<?php
if (is_file('./class/Slot.class.php')) { require_once('./class/Slot.class.php'); }
$slb = new SlotBean();
$slb->where = "id=".$_GET['id'];
$slots = $slb->getEntries();
if (count($slots) == 1) {
  $add = 0;
	$slot = $slots[0];
} else {
  header("Location: errorpage.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="HandheldFriendly" content="True" />
  <title>GAME</title>
  <link rel="icon" href="img/favicon.png" type="image/png">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://code.jquery.com/jquery-migrate-3.4.0.min.js" integrity="sha256-mBCu5+bVfYzOqpYyK4jm30ZxAZRomuErKEFJFIyrwvM=" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.6.1/js/iziModal.min.js"></script>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.6.1/css/iziModal.css">
  <link href="https://use.fontawesome.com/releases/v6.2.0/css/all.css" rel="stylesheet">
  <link rel="stylesheet" href="./css/style.css" media="screen">
  <style>
    .clock { 
      font-size: 1.3rem;
    }
  </style>
</head>
<body>
<!-- ========================================================================= -->
<input id="txt-id" type="hidden" value="<?= $slot->id ?>">
<nav class="navbar navbar-expand-lg navbar-light" style="background-color:#e3f2fd;">
  <div class="container-fluid text-center">
    <a class="navbar-brand" href="#"><span style="font-weight:bold;"><?= $slot->name ?></span></a>
  </div>
</nav>
<!-- ========================================================================= -->
<table class="table table-borderless" style="width:80%;">
  <tr>
    <td>
      <div class="text-center"><p id="realtime" class="clock"></p></div>
    </td>
  </tr>
  <tr>
    <td>
      <div class="input-group mb-3">
        ⚠️ 現在時刻以前のデータをクリアします<br>
         ✳️ よろしければクリアボタンをクリックしてください
      </div>
    </td>
  </tr>
  <tr>
    <td>
      <div class="text-center">
        <button id="btn-clear" class="btn btn-danger btn-sm btn-top-navi"><i class="fa-solid fa-circle-check">　クリア</i></button>
        <span>　</span>
        <button id="btn-close" class="btn btn-secondary btn-sm btn-top-navi"><i class="fa-regular fa-circle-xmark">　閉じる</i></button>
      </div>
    </td>
  </tr>
</table>

<input type="hidden" id="gkey" value="9">
<script>
const sleep = waitTime => new Promise(resolve => setTimeout(resolve, waitTime));

const ajaxClearData = (id) => {
  let data = { "id" : id,};
  let json = JSON.stringify(data);
  let xhr = new XMLHttpRequest();
  xhr.open("POST", "./ajax/ajaxClearData.php");
  xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded;charset=UTF-8");
  xhr.send(json);
  xhr.onreadystatechange = function () {
    try {
      if (xhr.readyState == 4 && xhr.status == 200) {
        let result = JSON.parse(xhr.response);
        $("#gkey").val(result.value);
      } else {
      }
    } catch (e) {
    }
  };
};

const winClose = () => {
  parent.location.reload();
  parent.$.fn.colorbox.close();
};

const showClock = () => {
  let nowTime = new Date();
  let nowMonth = nowTime.getMonth() + 1;
  let nowDate = nowTime.getDate();
  let nowHour = nowTime.getHours().toString().padStart(2, '0');
  let nowMin  = nowTime.getMinutes().toString().padStart(2, '0');
  let nowSec  = nowTime.getSeconds().toString().padStart(2, '0');
  let msg = "現在時刻：" + nowMonth + "月" + nowDate + "日　" + nowHour + ":" + nowMin + ":" + nowSec;
  document.getElementById("realtime").innerHTML = msg;
};

$(function() {
  setInterval('showClock()',1000);

  $("#btn-clear").on('click', function () { // クリア
    ajaxClearData(<?= $slot->id ?>);
    sleep(200).then(()=>{ winClose(); });
  });

  $("#btn-close").on('click', function () { // 閉じる
    winClose();
  });
});
</script>
</body>
</html>