<?php
if (is_file('./class/Slot.class.php')) { require_once('./class/Slot.class.php'); }




ini_set('display_errors', "On");
error_reporting(E_ALL);





$dbfile = '/var/www/html/db/slot.db';
$conn = new PDO('sqlite:' . $dbfile);

// DROP & CREATE TABLE
$ddl = 'DROP TABLE IF EXISTS t1';
$conn->query($ddl);
$ddl = 'CREATE TABLE t1(id int, os text)';
$conn->query($ddl);

// INSERT
$sql = "INSERT INTO t1 VALUES (1,'Windows'),(2,'Linux'),(3,'macOS'),(4,'Android'),(5,'iOS')";
$conn->query($sql);

// SELECT
$sql = 'SELECT * FROM t1 ORDER BY id';
$stmt = $conn->query($sql);
while ($row = $stmt->fetch(PDO::FETCH_ASSOC))
{
  echo $row['id'] . "," . $row['os'] . PHP_EOL;
}

/*

$sb = new SlotBean();
$pdo = $sb->getPDO();
//$ret = $sb->modSlot("UPD", 1, "TEST", "192.168.1.1", 1);
$num = 1;
$name = 'test';
$ip = '192.168.0.0';
$id = 1;
$sql = "update slot set num=:num,name=:name,ip=:ip where id=:id";
$sth = $pdo->prepare($sql);
$sth->bindValue(':num', $num);
$sth->bindValue(':name', $name);
$sth->bindValue(':ip', $ip);
$sth->bindValue(':id', $id);
$ret = $sth->execute();
*/



//$ret = $sb->modSlot($req['com'], $req['id'], $req['name'], $req['ip'], $req['num']);
//$ret = $req['com'] . $req['id'] . $req['name'] . $req['ip'] .$req['num'];
//$result =[ "value" => $ret, ];
//$json = json_encode($result, JSON_UNESCAPED_UNICODE);
?>
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="HandheldFriendly" content="True" />
  <title>SLOT</title>
  <link rel="icon" href="img/favicon.png" type="image/png">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://code.jquery.com/jquery-migrate-3.4.0.min.js" integrity="sha256-mBCu5+bVfYzOqpYyK4jm30ZxAZRomuErKEFJFIyrwvM=" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.6.1/js/iziModal.min.js"></script>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <!-- JSファイル読み込み -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.6.1/css/iziModal.css">
  <link rel="stylesheet" href="./css/style.css" media="screen">
</head>
<body>

<button id="btn">UPD</button>
<div id="UPD_SLOT"></div>

<script>

const ajaxSlot = (com, sid, sname, sip, snum) => {
  let data = { "com" : com, "id" : sid, "name" : sname, "ip" : sip, "num" : snum };
  let json = JSON.stringify(data);
  let xhr = new XMLHttpRequest();
  $("#UPD_SLOT").html("com " + com + " id " + sid + " sname " + sname + " sip " + sip + " num" + snum);
  xhr.open("POST", "./ajax/ajaxSlot.php");
  xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded;charset=UTF-8");
  xhr.send(json);
  xhr.onreadystatechange = function () {
    try {
      if (xhr.readyState == 4 && xhr.status == 200) {
        let result = JSON.parse(xhr.response);
        $("#UPD_SLOT").html(result.value);
//        open('about:blank', '_self').close();
///////////////        winClose();
//        setData(id, result.value);
      } else {
        $("#UPD_SLOT").html("ds");
      }
    } catch (e) {
        $("#UPD_SLOT").html("as");
    }
  };
};

$(function() {
  $("#btn").on('click', function () { // 登録
    ajaxSlot("UPD", 1, "ねぇ～ねぇ～島娘テスト", "192.168.0.0", 1);
  });
});
</script>
</body>
</html>
