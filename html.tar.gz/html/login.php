<?php
session_start();
if (is_file(dirname(__FILE__).DIRECTORY_SEPARATOR."config.php")) { require_once(dirname(__FILE__).DIRECTORY_SEPARATOR."config.php"); }
if (is_file('.'.DIRECTORY_SEPARATOR.'class'.DIRECTORY_SEPARATOR.'User.class.php')) { require_once('.'.DIRECTORY_SEPARATOR.'class'.DIRECTORY_SEPARATOR.'User.class.php'); }
$uid=$_POST['loginid'];
$pwd=$_POST['password'];
if (isset($uid) && isset($pwd)) {
  $ub = new UserBean();
  $ret = $ub->getLoginUser($uid, $pwd);
  if ((int)$ret == -1) {
    $message="!ユーザー名またはパスワードが違います!";
  } else {
      session_regenerate_id(TRUE); //セッションidを再発行
      $user = explode(",", $ret);
      $_SESSION["login"] = $user[0];//$_POST['uname']; //セッションにログイン情報を登録
      $_SESSION["admin"] = $user[1];//$_POST['uname']; //セッションにログイン情報を登録
      header("Location: index.php"); //ログイン後のページにリダイレクト
      exit();
  }
}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="HandheldFriendly" content="True" />
  <title>Login</title>
  <link rel="icon" href="img/favicon.png" type="image/png">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://code.jquery.com/jquery-migrate-3.4.0.min.js" integrity="sha256-mBCu5+bVfYzOqpYyK4jm30ZxAZRomuErKEFJFIyrwvM=" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.6.1/js/iziModal.min.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/izimodal/1.6.1/css/iziModal.css">
  <link rel="stylesheet" href="./css/style.css" media="screen">
</head>
<body>

<div style="margin-top: 10ex;"></div>
<section class="vh-100">
  <div class="container-fluid h-custom">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-md-9 col-lg-6 col-xl-5">
        <img src="./img/lock.png" class="img-fluid d-block mx-auto">
      </div>
      <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
        <form name="frm" id="login" action="login.php" method="post">
          <div style="color: red; height: 5ex;"><?= $message ?></div>
          <div class="form-outline mb-4">
            <input type="text" id="loginid" name="loginid" class="form-control form-control-lg" placeholder="ログインID" required />
            <label class="form-label" for="loginid">LoginID</label>
          </div>
          <div class="form-outline mb-3">
            <input type="password" id="password" name="password" class="form-control form-control-lg" placeholder="パスワード" required />
            <label class="form-label" for="password">Password</label>
          </div>
          <div class="text-center text-lg-start mt-4 pt-2">
            <button type="submit" class="btn btn-primary btn-lg" style="padding-left: 2.5rem; padding-right: 2.5rem;">Login</button>
            <p class="small fw-bold mt-2 pt-1 mb-0"></p>
          </div>
          <div style="height: 20ex;"></div>
        </form>
      </div>
    </div>
  </div>
  <div class="d-flex flex-column flex-md-row text-center text-md-start justify-content-between py-4 px-4 px-xl-5 bg-primary">
    <div class="text-white mb-3 mb-md-0">Copyright © 2024. All rights reserved.</div>
  </div>
<?php if (_DEBUG == 1) { ?>
  <div style="font-size:1em;margin-right:2em;text-align:right;"> ※use "admin/password777"</div>
<?php } ?>
</section>

</body>
</html>